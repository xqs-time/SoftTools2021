class NoReleasesException(Exception):
    pass